`use strict`

const containerEl = document.querySelector(".container")
const btnPlayEl = document.querySelector(".btn_again")
const btnCheckEl = document.querySelector(".btn_check")
const hideNumEl = document.querySelector(".hide_num")
const msgEl = document.querySelector(".message")
const inputNumEl = document.querySelector(".input_number")
const highScoreEl = document.querySelector(".high_score")
const scoreEl = document.querySelector(".score")


//rendon number 1 to 20
let secretnum = Math.trunc(Math.random() * 20 + 1)
let score = 20
let highScore = 0

console.log(secretnum)


//event to check hide num
btnCheckEl.addEventListener('click',() => {
   const guess = Number( inputNumEl.value)

   //check empty input
   if(guess){

      //not match hide number
      if(guess != secretnum){
          
          if(score > 1){
            score--;
            scoreEl.textContent = score

            msgEl.textContent = guess >secretnum ? `Too High` : `To Low`
            scoreEl.textContent = score
           } else {
            displaymessage("you've lossed the game")
            containerEl.style.backgroundColor = "#fff"
            scoreEl.textContent = 0
          } 
         } else {
            //success
            hideNumEl.textContent = secretnum
            hideNumEl.style.width = '50%'
             containerEl.style.backgroundColor = "#e0d8d3"
            displaymessage("congratulations")
         } 
        } else {
    
     displaymessage(`please enter the number: (`)
   }
})


const displaymessage = function(message){
    msgEl.textContent = message
}

//reset game
btnPlayEl.addEventListener('click',()=>{
    score =20
    secretnum = Math.floor(Math.random()*20)+1
    scoreEl.textContent = score
    scoreEl.textContent = "?"
    hideNumEl.style.width ="25%"
    inputNumEl.value = ""
    containerEl.style.backgroundColor = "#ddd"
   displaymessage("start guessing.....")
})