let playerScore = 0;
let computerScore = 0;

function playGame(playerChoice) {
    const choices = ["rock", "paper", "scissors"];
    const computerChoice = choices[Math.floor(Math.random() * choices.length)];

    let result = "";

    if (playerChoice === computerChoice) {
        result = "It's a tie!";
    } else if (
        (playerChoice === "rock" && computerChoice === "scissors") ||
        (playerChoice === "paper" && computerChoice === "rock") ||
        (playerChoice === "scissors" && computerChoice === "paper")
    ) {
        result = "You win!";
        playerScore++;
        document.getElementById("playerscoredisplay").textContent = playerScore;
    } else {
        result = "Computer wins!";
        computerScore++;
        document.getElementById("computerscoredisplay").textContent = computerScore;
    }

    document.getElementById("playerdisplay").innerText = `Player: ${playerChoice}`;
    document.getElementById("computerdisplay").innerText = `Computer: ${computerChoice}`;
    document.getElementById("resultdisplay").innerText = result;

    // Add colors to result text
    const resultDisplay = document.getElementById("resultdisplay");
    resultDisplay.classList.remove("greenText", "redText");

    if (result === "You win!") {
        resultDisplay.classList.add("greenText");
    } else if (result === "Computer wins!") {
        resultDisplay.classList.add("redText");
    }
}
